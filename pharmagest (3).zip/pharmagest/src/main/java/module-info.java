module com.example.pharmagest {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;


    opens com.example.pharmagest to javafx.fxml;
    exports com.example.pharmagest;
    exports com.example.pharmagest.controllers;
    opens com.example.pharmagest.controllers to javafx.fxml;
    exports com.example.pharmagest.model;
    opens com.example.pharmagest.model to javafx.fxml;
    exports com.example.pharmagest.service;
    opens com.example.pharmagest.service to javafx.fxml;





}
