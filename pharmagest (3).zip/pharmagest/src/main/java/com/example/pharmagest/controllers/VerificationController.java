package com.example.pharmagest.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;

public class VerificationController {
    @FXML private TextField ticketIdField;
    @FXML private Label lblStatus;

    @FXML
    public void verifierTicket() {
        lblStatus.setText("Vérification en cours...");
    }
}
