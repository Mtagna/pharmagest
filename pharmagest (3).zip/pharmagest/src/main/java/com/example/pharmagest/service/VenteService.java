package com.example.pharmagest.service;

import com.example.pharmagest.model.Medicament;
import com.example.pharmagest.model.MedicamentPanier;
import com.example.pharmagest.repository.TicketRepository;
import com.example.pharmagest.repository.MedicamentRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.List;

public class VenteService {
    private ObservableList<MedicamentPanier> panierList = FXCollections.observableArrayList();
    private final TicketRepository ticketRepository;
    private final MedicamentRepository medicamentRepository;

    public VenteService(TicketRepository ticketRepository, MedicamentRepository medicamentRepository) {
        this.ticketRepository = ticketRepository;
        this.medicamentRepository = medicamentRepository;
    }

    public void ajouterAuPanier(Medicament medicament) {
        for (MedicamentPanier item : panierList) {
            if (item.getMedicament().getIdMedicament() == medicament.getIdMedicament()) {
                item.setQuantite(item.getQuantite() + 1);
                return;
            }
        }
        panierList.add(new MedicamentPanier(medicament, 1));
    }

    public void modifierQuantite(MedicamentPanier medicamentPanier, int nouvelleQuantite) {
        if (nouvelleQuantite > 0) {
            medicamentPanier.setQuantite(nouvelleQuantite);
        } else {
            panierList.remove(medicamentPanier);
        }
    }

    public void retirerDuPanier(MedicamentPanier medicamentPanier) {
        panierList.remove(medicamentPanier);
    }

    public double calculerTotal() {
        return panierList.stream().mapToDouble(item -> item.getMedicament().getPrixVente() * item.getQuantite()).sum();
    }

    public ObservableList<MedicamentPanier> getPanierList() {
        return panierList;
    }

    public boolean validerPaiement(int ticketId) {
        if (ticketId > 0) {
            return true;
        }
        return false;
    }

    public int creerTicket(List<Medicament> medicaments) {
        // Implémentation fictive de la création d'un ticket
        return ticketRepository.genererNouveauTicket(medicaments);
    }

    public void validerVente() {
    }

    public void viderPanier() {
    }
}
