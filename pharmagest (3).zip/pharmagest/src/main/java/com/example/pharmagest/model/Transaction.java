package com.example.pharmagest.model;

public class Transaction {
    private Ticket ticket;
    private boolean paiementEffectue;

    public Transaction(Ticket ticket) {
        this.ticket = ticket;
        this.paiementEffectue = false;
    }

    public void effectuerPaiement() {
        this.paiementEffectue = true;
        this.ticket.setPaye(true);
    }

    public boolean isPaiementEffectue() {
        return paiementEffectue;
    }
}
