package com.example.pharmagest.test;

import com.example.pharmagest.model.User;
import com.example.pharmagest.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;

public class UserRepositoryTest {

    public static void main(String[] args) {
        UserRepository userRepository = new UserRepository();

        // Suppression d'un utilisateur avec un ID existant
        int userIdToDelete = 8; // Assure-toi que cet ID existe dans la table

        boolean isDeleted = userRepository.deleteUserById(userIdToDelete);

        // Affichage du résultat
        if (isDeleted) {
            System.out.println("Utilisateur supprimé avec succès (ID = " + userIdToDelete + ").");
        } else {
            System.out.println("Erreur : aucun utilisateur trouvé avec l'ID " + userIdToDelete + ".");
        }
    }

/*
    public static void main(String[] args) {
        UserRepository userRepository = new UserRepository();

        // Supposons qu'un utilisateur avec l'ID 1 existe déjà
        User updatedUser = new User(
                3, // ID de l'utilisateur à modifier
                "Jean", // Nouveau prénom
                "Dupont", // Nouveau nom
                "jeandupont", // Nouveau username
                "newpassword123", // Nouveau mot de passe
                "Vendeur", // Nouveau rôle
                LocalDateTime.now() // Nouvelle date de connexion
        );

        // Appel de la méthode updateUser
        boolean isUpdated = userRepository.updateUser(updatedUser);

        // Résultat
        if (isUpdated) {
            System.out.println("Utilisateur mis à jour avec succès : " + updatedUser);
        } else {
            System.out.println("Erreur lors de la mise à jour de l'utilisateur.");
        }
    }*/


 /*   public static void main(String[] args) {
        UserRepository userRepository = new UserRepository();

        // Création d'un nouvel utilisateur
        User newUser = new User("Tay", "Davis", "dodol", "securepassword12345", "Vendeur", LocalDateTime.now());

        // Ajout de l'utilisateur
        boolean isAdded = userRepository.addUser(newUser);

        if (isAdded) {
            System.out.println("Utilisateur ajouté avec succès : " + newUser);
        } else {
            System.out.println("Erreur lors de l'ajout de l'utilisateur.");
        }
    }*/
/*
    public static void main(String[] args) {
        UserRepository userRepository = new UserRepository();

        // Tester la méthode getAllUsers()
        List<User> users = userRepository.getAllUsers();

        // Afficher les utilisateurs pour vérifier
        if (users.isEmpty()) {
            System.out.println("Aucun utilisateur trouvé.");
        } else {
            for (User user : users) {
                System.out.println(user);
            }
        }
    }*/
}
