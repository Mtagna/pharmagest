package com.example.pharmagest.repository;

import com.example.pharmagest.database.DatabaseConnection;
import com.example.pharmagest.model.Medicament;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicamentRepository {

    public List<Medicament> getAllMedicaments() {
        List<Medicament> medicaments = new ArrayList<>();
        String query = "SELECT * FROM medicament";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Medicament medicament = new Medicament(
                        resultSet.getInt("idmedicament"),
                        resultSet.getString("nom"),
                        resultSet.getString("forme"),
                        resultSet.getDouble("prix_achat"),
                        resultSet.getDouble("prix_vente"),
                        resultSet.getInt("stock"),
                        resultSet.getInt("seuil_commande"),
                        resultSet.getInt("quantite_max"),
                        resultSet.getInt("idfamille"),
                        resultSet.getInt("idunite")
                );
                medicaments.add(medicament);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicaments;
    }

    public boolean addMedicament(Medicament medicament) {
        String query = "INSERT INTO public.medicament (nom, forme, prix_achat, prix_vente, stock, seuil_commande, quantite_max, idfamille, idunite) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, medicament.getNom());
            preparedStatement.setString(2, medicament.getForme());
            preparedStatement.setDouble(3, medicament.getPrixAchat());
            preparedStatement.setDouble(4, medicament.getPrixVente());
            preparedStatement.setInt(5, medicament.getStock());
            preparedStatement.setInt(6, medicament.getSeuilCommande());
            preparedStatement.setInt(7, medicament.getQuantiteMax());
            preparedStatement.setInt(8, medicament.getIdFamille());
            preparedStatement.setInt(9, medicament.getIdUnite());

            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Ajoute les méthodes update et delete si nécessaire

    public boolean updateMedicament(Medicament medicament) {
        String query = "UPDATE public.medicament " +
                "SET nom = ?, forme = ?, prix_achat = ?, prix_vente = ?, stock = ?, " +
                "seuil_commande = ?, quantite_max = ?, idfamille = ?, idunite = ? " +
                "WHERE idmedicament = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, medicament.getNom());
            preparedStatement.setString(2, medicament.getForme());
            preparedStatement.setDouble(3, medicament.getPrixAchat());
            preparedStatement.setDouble(4, medicament.getPrixVente());
            preparedStatement.setInt(5, medicament.getStock());
            preparedStatement.setInt(6, medicament.getSeuilCommande());
            preparedStatement.setInt(7, medicament.getQuantiteMax());
            preparedStatement.setInt(8, medicament.getIdFamille());
            preparedStatement.setInt(9, medicament.getIdUnite());
            preparedStatement.setInt(10, medicament.getIdMedicament()); // ID du médicament à mettre à jour

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Retourne vrai si au moins une ligne a été mise à jour

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean deleteMedicamentById(int id) {
        String query = "DELETE FROM public.medicament WHERE idmedicament = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Retourne vrai si une ligne a été supprimée

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
