package com.example.pharmagest.controllers;

import com.example.pharmagest.model.Medicament;
import com.example.pharmagest.repository.MedicamentRepository;
import com.example.pharmagest.repository.TicketRepository;
import com.example.pharmagest.service.MedicamentService;
import com.example.pharmagest.service.VenteService;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class PharmacienController {

    @FXML private TableView<Medicament> medicamentTable;
    @FXML private TableColumn<Medicament, Integer> idColumn;
    @FXML private TableColumn<Medicament, String> nomColumn;
    @FXML private TableColumn<Medicament, String> formeColumn;
    @FXML private TableColumn<Medicament, Double> prixVenteColumn;
    @FXML private TableColumn<Medicament, Integer> stockColumn;

    @FXML private Button genererTicketButton;

    private MedicamentService medicamentService = new MedicamentService();
    private ObservableList<Medicament> medicamentList;
//    private VenteService venteService = new VenteService(new TicketRepository(), new MedicamentRepository());


    @FXML
    public void initialize() {
        // Lier les colonnes aux attributs des médicaments
        idColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getIdMedicament()));
        nomColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getNom()));
        formeColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getForme()));
        prixVenteColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getPrixVente()));
        stockColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getStock()));

        // Charger les médicaments dans le tableau
        loadMedicaments();
    }

    private void loadMedicaments() {
        List<Medicament> medicaments = medicamentService.getAllMedicaments();

        // Vérifie si les médicaments sont bien récupérés
        System.out.println("Médicaments récupérés : " + medicaments.size());

        medicamentList = FXCollections.observableArrayList(medicaments);
        medicamentTable.setItems(medicamentList);
    }


    @FXML
    public void genererTicket() {
        List<Medicament> selection = medicamentTable.getSelectionModel().getSelectedItems();
        if (!selection.isEmpty()) {
            //venteService.creerTicket(selection);
            System.out.println("Ticket généré avec succès !");
        } else {
            System.out.println("⚠ Sélectionnez au moins un médicament !");
        }
    }
}
