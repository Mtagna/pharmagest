package com.example.pharmagest.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:postgresql://postgresql-smaina.alwaysdata.net:5432/smaina_pharmagestdb";
    private static final String USER = "smaina";
    private static final String PASSWORD = "Montagneux@8";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
