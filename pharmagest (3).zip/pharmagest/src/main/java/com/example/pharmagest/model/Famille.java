package com.example.pharmagest.model;

public class Famille {
}
