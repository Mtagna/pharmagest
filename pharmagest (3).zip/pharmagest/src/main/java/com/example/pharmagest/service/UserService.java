package com.example.pharmagest.service;

import com.example.pharmagest.model.User;
import com.example.pharmagest.repository.UserRepository;

import java.util.List;

public class UserService {

    private final UserRepository userRepository = new UserRepository();

    public List<User> getAllUsers() {
        return userRepository.getAllUsers();
    }

    public boolean addUser(User user) {
        return userRepository.addUser(user);
    }

    public boolean updateUser(User user) {
        return userRepository.updateUser(user);
    }

    public boolean deleteUserById(int id) {
        return userRepository.deleteUserById(id);
    }
}

/*package com.example.pharmagest.service;

import com.example.pharmagest.model.User;
import com.example.pharmagest.repository.UserRepository;

import java.util.List;

public class UserService {

    private final UserRepository userRepository = new UserRepository();

    // Récupérer tous les utilisateurs
    public List<User> getAllUsers() {
        return userRepository.getAllUsers();
    }

    // Ajouter un utilisateur
    public boolean addUser(User user) {
        // Logique métier (exemple : validation avant ajout)
        if (user.getFirstName().isEmpty() || user.getLastName().isEmpty() || user.getUsername().isEmpty()) {
            throw new IllegalArgumentException("Tous les champs sont obligatoires.");
        }
        return userRepository.addUser(user);
    }

    // Modifier un utilisateur
    public boolean updateUser(User user) {
        // Exemple : vérifier que l'utilisateur existe avant modification
        if (userRepository.getAllUsers().stream().noneMatch(u -> u.getId() == user.getId())) {
            throw new IllegalArgumentException("Utilisateur introuvable.");
        }
        return userRepository.updateUser(user);
    }

    // Supprimer un utilisateur
    public boolean deleteUserById(int id) {
        return userRepository.deleteUserById(id);
    }
}*/
