package com.example.pharmagest.model;

import java.sql.Date;

public class Vente {
    private int idVente;
    private Date dateVente;
    private double montantTotal;
    private String typeVente; // Libre ou Prescrite
    private int idVendeur;
    private String statutVente; // en attente, payé, finalisé

    // Constructeur
    public Vente(int idVente, Date dateVente, double montantTotal, String typeVente, int idVendeur, String statutVente) {
        this.idVente = idVente;
        this.dateVente = dateVente;
        this.montantTotal = montantTotal;
        this.typeVente = typeVente;
        this.idVendeur = idVendeur;
        this.statutVente = statutVente;
    }

    // Getters et Setters
    public int getIdVente() { return idVente; }
    public void setIdVente(int idVente) { this.idVente = idVente; }

    public Date getDateVente() { return dateVente; }
    public void setDateVente(Date dateVente) { this.dateVente = dateVente; }

    public double getMontantTotal() { return montantTotal; }
    public void setMontantTotal(double montantTotal) { this.montantTotal = montantTotal; }

    public String getTypeVente() { return typeVente; }
    public void setTypeVente(String typeVente) { this.typeVente = typeVente; }

    public int getIdVendeur() { return idVendeur; }
    public void setIdVendeur(int idVendeur) { this.idVendeur = idVendeur; }

    public String getStatutVente() { return statutVente; }
    public void setStatutVente(String statutVente) { this.statutVente = statutVente; }
}
