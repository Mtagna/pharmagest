package com.example.pharmagest.controllers;

import com.example.pharmagest.model.Fournisseur;
import com.example.pharmagest.service.FournisseurService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class FournisseurController {
    @FXML private TableView<Fournisseur> fournisseurTable;
    @FXML private TableColumn<Fournisseur, Integer> idColumn;
    @FXML private TableColumn<Fournisseur, String> nomColumn;
    @FXML private TableColumn<Fournisseur, String> adresseColumn;
    @FXML private TableColumn<Fournisseur, String> contactColumn;
    @FXML private TableColumn<Fournisseur, String> emailColumn;
    @FXML private TextField nomField;
    @FXML private TextField adresseField;
    @FXML private TextField contactField;
    @FXML private TextField emailField;
    @FXML private Button addButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;

    private final FournisseurService fournisseurService = new FournisseurService();
    private final ObservableList<Fournisseur> fournisseurList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getIdFournisseur()).asObject());
        nomColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getNom()));
        adresseColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getAdresse()));
        contactColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getContact()));
        emailColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEmail()));

        List<Fournisseur> fournisseurs = fournisseurService.getAllFournisseurs();
        fournisseurList.setAll(fournisseurs);
        fournisseurTable.setItems(fournisseurList);
    }

    @FXML
    public void addFournisseur() {
        String nom = nomField.getText();
        String adresse = adresseField.getText();
        String contact = contactField.getText();
        String email = emailField.getText();

        if (!nom.isEmpty() && !email.isEmpty()) {
            Fournisseur fournisseur = new Fournisseur(0, nom, adresse, contact, email);
            fournisseurService.addFournisseur(fournisseur);
            initialize(); // Rafraîchir
        }
    }

    @FXML
    public void updateFournisseur() {
        Fournisseur selectedFournisseur = fournisseurTable.getSelectionModel().getSelectedItem();
        if (selectedFournisseur != null) {
            selectedFournisseur.setNom(nomField.getText());
            selectedFournisseur.setAdresse(adresseField.getText());
            selectedFournisseur.setContact(contactField.getText());
            selectedFournisseur.setEmail(emailField.getText());

            fournisseurService.updateFournisseur(selectedFournisseur);
            initialize(); // Rafraîchir
        }
    }

    @FXML
    public void deleteFournisseur() {
        Fournisseur selectedFournisseur = fournisseurTable.getSelectionModel().getSelectedItem();
        if (selectedFournisseur != null) {
            fournisseurService.deleteFournisseur(selectedFournisseur.getIdFournisseur());
            initialize(); // Rafraîchir
        }
    }

}
