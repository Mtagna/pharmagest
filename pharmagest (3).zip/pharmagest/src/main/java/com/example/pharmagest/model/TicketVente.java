package com.example.pharmagest.model;

import java.sql.Timestamp;

public class TicketVente {
    private int idTicket;
    private int idVente;
    private Timestamp dateTicket;
    private String statutTicket; // en attente, payé
    private double montantTotal;
    private int idCaissier;

    // Constructeur
    public TicketVente(int idTicket, int idVente, Timestamp dateTicket, String statutTicket, double montantTotal, int idCaissier) {
        this.idTicket = idTicket;
        this.idVente = idVente;
        this.dateTicket = dateTicket;
        this.statutTicket = statutTicket;
        this.montantTotal = montantTotal;
        this.idCaissier = idCaissier;
    }

    // Getters et Setters
    public int getIdTicket() { return idTicket; }
    public void setIdTicket(int idTicket) { this.idTicket = idTicket; }

    public int getIdVente() { return idVente; }
    public void setIdVente(int idVente) { this.idVente = idVente; }

    public Timestamp getDateTicket() { return dateTicket; }
    public void setDateTicket(Timestamp dateTicket) { this.dateTicket = dateTicket; }

    public String getStatutTicket() { return statutTicket; }
    public void setStatutTicket(String statutTicket) { this.statutTicket = statutTicket; }

    public double getMontantTotal() { return montantTotal; }
    public void setMontantTotal(double montantTotal) { this.montantTotal = montantTotal; }

    public int getIdCaissier() { return idCaissier; }
    public void setIdCaissier(int idCaissier) { this.idCaissier = idCaissier; }
}
