package com.example.pharmagest.controllers;

import com.example.pharmagest.service.VenteService;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;

public class CaissiereController {
    @FXML private TextField ticketIdField;
    @FXML private Label lblStatus;

    private VenteService venteService;

    @FXML
    public void validerPaiement() {
        int ticketId = Integer.parseInt(ticketIdField.getText());
        boolean success = venteService.validerPaiement(ticketId);
        lblStatus.setText(success ? "✅ Paiement validé !" : "❌ Ticket introuvable ou déjà payé.");
    }
}
