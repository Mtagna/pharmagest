package com.example.pharmagest.controllers;

import com.example.pharmagest.MainApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class MaintenanceController {

    @FXML
    private Button cancelButton;
    @FXML
    private Button medicamentButton;
    @FXML
    private Button retour_btn;

    private Stage stage; // Déclaration de la variable stage

    @FXML
    public void medicamentButtonOnAction(ActionEvent e) throws IOException {
        // Chargement de l'interface Médicament
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("medicament.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 600);
        stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setTitle("CRUD Médicament");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void cancelButtonOnAction(ActionEvent e) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("Dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 600);
        stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setTitle("Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void handleBackToLogin(ActionEvent event) {
        try {
            Parent loginRoot = FXMLLoader.load(MainApplication.class.getResource("login.fxml"));
            Stage stage = (Stage) retour_btn.getScene().getWindow();
            Scene scene = new Scene(loginRoot);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    public void userButtonOnAction(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("user.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 600);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Gestion des Utilisateurs");
        stage.setScene(scene);
        stage.show();
    }

    public void loginButtonOnAction(ActionEvent actionEvent) {
    }

    @FXML
    public void openFournisseurView(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/pharmagest/fournisseur.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Gestion des Fournisseurs");
            stage.setScene(new Scene(root, 900, 600));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("❌ Erreur lors de l'ouverture de la fenêtre Fournisseur !");
        }
    }
}
