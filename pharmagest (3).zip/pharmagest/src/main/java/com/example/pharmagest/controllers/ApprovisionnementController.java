package com.example.pharmagest.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ApprovisionnementController {

    @FXML
    private TableView<?> tableMedicamentSousSeuil;

    @FXML
    private TableColumn<?, ?> colNom;

    @FXML
    private TableColumn<?, ?> colStock;

    @FXML
    private TableColumn<?, ?> colSeuil;

    @FXML
    private TableColumn<?, ?> colMax;

    @FXML
    private TableColumn<?, ?> colACommander;

    @FXML
    private Button btnValiderCommande;

    @FXML
    public void initialize() {
        // Initialisation ou remplissage du tableau si nécessaire
    }
}
