package pkg.tpvente;

public class LigneVendu {

    private int ligne_vendu_id;
    private int num_vente;
    private int idmedicament;
    private int qte_vendue;

    public LigneVendu(int ligne_vendu_id, int num_vente, int idmedicament, int qte_vendue) {
        this.ligne_vendu_id = ligne_vendu_id;
        this.num_vente = num_vente;
        this.idmedicament = idmedicament;
        this.qte_vendue = qte_vendue;
    }

    public int getLigne_vendu_id() {
        return ligne_vendu_id;
    }

    public void setLigne_vendu_id(int ligne_vendu_id) {
        this.ligne_vendu_id = ligne_vendu_id;
    }

    public int getNum_vente() {
        return num_vente;
    }

    public void setNum_vente(int num_vente) {
        this.num_vente = num_vente;
    }

    public int getidmedicament() {
        return idmedicament;
    }

    public void setMedicament_dci(int medicament_dci) {
        this.idmedicament = idmedicament;
    }

    public int getQte_vendue() {
        return qte_vendue;
    }

    public void setQte_vendue(int qte_vendue) {
        this.qte_vendue = qte_vendue;
    }
}
