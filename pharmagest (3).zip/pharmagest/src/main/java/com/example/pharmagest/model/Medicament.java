package com.example.pharmagest.model;

public class Medicament {
    private int idMedicament;
    private String nom;
    private String forme;
    private double prixAchat;
    private double prixVente;
    private int stock;
    private int seuilCommande;
    private int quantiteMax;
    private int idFamille;
    private int idUnite;

    public Medicament(int idMedicament, String nom, String forme, double prixAchat, double prixVente, int stock, int seuilCommande, int quantiteMax, int idFamille, int idUnite) {
        this.idMedicament = idMedicament;
        this.nom = nom;
        this.forme = forme;
        this.prixAchat = prixAchat;
        this.prixVente = prixVente;
        this.stock = stock;
        this.seuilCommande = seuilCommande;
        this.quantiteMax = quantiteMax;
        this.idFamille = idFamille;
        this.idUnite = idUnite;
    }

    // Getters et Setters
    public int getIdMedicament() { return idMedicament; }
    public void setIdMedicament(int idMedicament) { this.idMedicament = idMedicament; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public String getForme() { return forme; }
    public void setForme(String forme) { this.forme = forme; }
    public double getPrixAchat() { return prixAchat; }
    public void setPrixAchat(double prixAchat) { this.prixAchat = prixAchat; }
    public double getPrixVente() { return prixVente; }
    public void setPrixVente(double prixVente) { this.prixVente = prixVente; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public int getSeuilCommande() { return seuilCommande; }
    public void setSeuilCommande(int seuilCommande) { this.seuilCommande = seuilCommande; }
    public int getQuantiteMax() { return quantiteMax; }
    public void setQuantiteMax(int quantiteMax) { this.quantiteMax = quantiteMax; }
    public int getIdFamille() { return idFamille; }
    public void setIdFamille(int idFamille) { this.idFamille = idFamille; }
    public int getIdUnite() { return idUnite; }
    public void setIdUnite(int idUnite) { this.idUnite = idUnite; }

    public Integer getIdmedicament() {
        return idMedicament;
    }

}
