package com.example.pharmagest.model;

public class Fournisseur {
    private int idFournisseur;
    private String nom;
    private String adresse;
    private String contact;
    private String email;

    // ✅ Constructeur par défaut (nécessaire pour Hibernate/JPA)
    public Fournisseur() {
    }

    // ✅ Constructeur avec paramètres (utilisé pour le CRUD)
    public Fournisseur(int idFournisseur, String nom, String adresse, String contact, String email) {
        this.idFournisseur = idFournisseur;
        this.nom = nom;
        this.adresse = adresse;
        this.contact = contact;
        this.email = email;
    }

    // ✅ Getters et Setters
    public int getIdFournisseur() { return idFournisseur; }
    public void setIdFournisseur(int idFournisseur) { this.idFournisseur = idFournisseur; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getAdresse() { return adresse; }
    public void setAdresse(String adresse) { this.adresse = adresse; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
