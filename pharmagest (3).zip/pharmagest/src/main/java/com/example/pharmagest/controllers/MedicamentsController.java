package com.example.pharmagest.controllers;

import com.example.pharmagest.model.Medicament;
import com.example.pharmagest.service.MedicamentService;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public class MedicamentsController {

    @FXML private TableView<Medicament> medicamentTable;
    @FXML private TableColumn<Medicament, Integer> idColumn;
    @FXML private TableColumn<Medicament, String> nomColumn;
    @FXML private TableColumn<Medicament, String> formeColumn;
    @FXML private TableColumn<Medicament, Double> prixAchatColumn;
    @FXML private TableColumn<Medicament, Double> prixVenteColumn;
    @FXML private TableColumn<Medicament, Integer> stockColumn;
    @FXML private TableColumn<Medicament, Integer> seuilCommandeColumn;
    @FXML private TableColumn<Medicament, Integer> quantiteMaxColumn;
    @FXML private TableColumn<Medicament, String> familleColumn;
    @FXML private TableColumn<Medicament, String> uniteColumn;

    @FXML private TextField nomField, formeField, prixAchatField, prixVenteField, stockField;
    @FXML private TextField seuilCommandeField, quantiteMaxField, familleField;
    @FXML private TextField idFamilleField;
    @FXML private TextField idUniteField;


    private final MedicamentService medicamentService = new MedicamentService();
    private ObservableList<Medicament> medicamentList;

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getIdMedicament()));
        nomColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getNom()));
        formeColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getForme()));
        prixAchatColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getPrixAchat()));
        prixVenteColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getPrixVente()));
        stockColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getStock()));
        seuilCommandeColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getSeuilCommande()));
        quantiteMaxColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getQuantiteMax()));
        familleColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getIdFamille()).asString());
        uniteColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getIdUnite()).asString());

        loadMedicaments();
    }

    private void loadMedicaments() {
        List<Medicament> medicaments = medicamentService.getAllMedicaments();
        medicamentList = FXCollections.observableArrayList(medicaments);
        medicamentTable.setItems(medicamentList);
    }

    @FXML
    public void backToMaintenanceOnAction(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/pharmagest/maintenance.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 900, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Maintenance");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addMedicamentOnAction(ActionEvent event) {
        Medicament newMedicament = new Medicament(
                0,
                nomField.getText(),
                formeField.getText(),
                new BigDecimal(prixAchatField.getText()).doubleValue(),
                new BigDecimal(prixVenteField.getText()).doubleValue(),
                Integer.parseInt(stockField.getText()),
                Integer.parseInt(seuilCommandeField.getText()),
                Integer.parseInt(quantiteMaxField.getText()),
                Integer.parseInt(idFamilleField.getText()),
                Integer.parseInt(idUniteField.getText())
        );

        if (medicamentService.addMedicament(newMedicament)) {
            showAlert("Succès", "Médicament ajouté avec succès.", Alert.AlertType.INFORMATION);
            loadMedicaments();
        }
    }
    @FXML
    public void updateMedicamentOnAction(ActionEvent event) {
        Medicament selectedMedicament = medicamentTable.getSelectionModel().getSelectedItem();
        if (selectedMedicament != null) {
            selectedMedicament.setNom(nomField.getText());
            selectedMedicament.setForme(formeField.getText());
            selectedMedicament.setPrixAchat(Double.parseDouble(prixAchatField.getText()));
            selectedMedicament.setPrixVente(Double.parseDouble(prixVenteField.getText()));
            selectedMedicament.setStock(Integer.parseInt(stockField.getText()));
            selectedMedicament.setSeuilCommande(Integer.parseInt(seuilCommandeField.getText()));
            selectedMedicament.setQuantiteMax(Integer.parseInt(quantiteMaxField.getText()));
            selectedMedicament.setIdFamille(Integer.parseInt(familleField.getText()));
            selectedMedicament.setIdUnite(Integer.parseInt(idUniteField.getText()));

            if (medicamentService.updateMedicament(selectedMedicament)) {
                showAlert("Succès", "Médicament mis à jour avec succès.", Alert.AlertType.INFORMATION);
                loadMedicaments();
            } else {
                showAlert("Erreur", "La mise à jour a échoué.", Alert.AlertType.ERROR);
            }
        } else {
            showAlert("Erreur", "Veuillez sélectionner un médicament à modifier.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void deleteMedicamentOnAction(ActionEvent event) {
        Medicament selectedMedicament = medicamentTable.getSelectionModel().getSelectedItem();
        if (selectedMedicament != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation de suppression");
            alert.setHeaderText("Supprimer le médicament ?");
            alert.setContentText("Voulez-vous vraiment supprimer ce médicament ?");

            if (alert.showAndWait().get() == ButtonType.OK) {
                if (medicamentService.deleteMedicamentById(selectedMedicament.getIdMedicament())) {
                    showAlert("Succès", "Médicament supprimé avec succès.", Alert.AlertType.INFORMATION);
                    loadMedicaments();
                } else {
                    showAlert("Erreur", "La suppression a échoué.", Alert.AlertType.ERROR);
                }
            }
        } else {
            showAlert("Erreur", "Veuillez sélectionner un médicament à supprimer.", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
