package com.example.pharmagest.model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

import javafx.beans.property.*;

public class TransactionItem {
    private final StringProperty dci;
    private final DoubleProperty prixVente;
    private final IntegerProperty quantiteVendue;
    private final DoubleProperty total;

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    private final IntegerProperty id;

    public TransactionItem(String dci, double prixVente, int quantiteVendue, int id) {
        this.dci = new SimpleStringProperty(dci);
        this.prixVente = new SimpleDoubleProperty(prixVente);
        this.quantiteVendue = new SimpleIntegerProperty(quantiteVendue);
        this.total = new SimpleDoubleProperty(prixVente * quantiteVendue);
        this.id = new SimpleIntegerProperty(id);

        // Bind total to prixVente and quantiteVendue
        this.total.bind(this.prixVente.multiply(this.quantiteVendue));
    }

    // Getters and setters
    public String getDCI() {
        return dci.get();
    }

    public void setDCI(String dci) {
        this.dci.set(dci);
    }

    public StringProperty dciProperty() {
        return dci;
    }

    public double getPrixVente() {
        return prixVente.get();
    }

    public void setPrixVente(double prixVente) {
        this.prixVente.set(prixVente);
    }

    public DoubleProperty prixVenteProperty() {
        return prixVente;
    }

    public int getQuantiteVendue() {
        return quantiteVendue.get();
    }

    public void setQuantiteVendue(int quantiteVendue) {
        this.quantiteVendue.set(quantiteVendue);
    }

    public IntegerProperty quantiteVendueProperty() {
        return quantiteVendue;
    }

    public double getTotal() {
        return total.get();
    }

    public DoubleProperty totalProperty() {
        return total;
    }
}
