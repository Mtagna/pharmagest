package com.example.pharmagest.controllers;

import com.example.pharmagest.model.User;
import com.example.pharmagest.service.UserService;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

public class UserController {

    @FXML
    private TableView<User> userTable;
    @FXML
    private TableColumn<User, Integer> idColumn;
    @FXML
    private TableColumn<User, String> firstNameColumn;
    @FXML
    private TableColumn<User, String> lastNameColumn;
    @FXML
    private TableColumn<User, String> usernameColumn;
    @FXML
    private TableColumn<User, String> roleColumn;
    @FXML
    private TableColumn<User, String> lastLoginColumn;

    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private ChoiceBox<String> roleChoiceBox;

    private final UserService userService = new UserService();
    private ObservableList<User> userList;

    @FXML
    public void initialize() {
        // Configuration des colonnes
        idColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));
        firstNameColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getFirstName()));
        lastNameColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getLastName()));
        usernameColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getUsername()));
        roleColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getRole()));
        lastLoginColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(
                cellData.getValue().getLastLogin() != null ? cellData.getValue().getLastLogin().toString() : "Jamais"
        ));

        // Initialisation des rôles possibles
        roleChoiceBox.setItems(FXCollections.observableArrayList("Pharmacien", "Vendeur"));

        // Charger les utilisateurs dans la table
        loadUsers();
    }

    private void loadUsers() {
        List<User> users = userService.getAllUsers();
        userList = FXCollections.observableArrayList(users);
        userTable.setItems(userList);
    }

    @FXML
    public void addUserOnAction(ActionEvent event) {
        if (validateInput()) {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String username = usernameField.getText();
            String password = passwordField.getText();
            String role = roleChoiceBox.getValue();

            User newUser = new User(0, firstName, lastName, username, password, role, LocalDateTime.now());
            if (userService.addUser(newUser)) {
                showAlert("Succès", "Utilisateur ajouté avec succès.", Alert.AlertType.INFORMATION);
                loadUsers();
            } else {
                showAlert("Erreur", "L'ajout de l'utilisateur a échoué.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    public void updateUserOnAction(ActionEvent event) {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser != null && validateInput()) {
            selectedUser.setFirstName(firstNameField.getText());
            selectedUser.setLastName(lastNameField.getText());
            selectedUser.setUsername(usernameField.getText());
            selectedUser.setPassword(passwordField.getText());
            selectedUser.setRole(roleChoiceBox.getValue());

            if (userService.updateUser(selectedUser)) {
                showAlert("Succès", "Utilisateur modifié avec succès.", Alert.AlertType.INFORMATION);
                loadUsers();
            } else {
                showAlert("Erreur", "La modification a échoué.", Alert.AlertType.ERROR);
            }
        } else {
            showAlert("Erreur", "Veuillez sélectionner un utilisateur à modifier.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void deleteUserOnAction(ActionEvent event) {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation de suppression");
            alert.setHeaderText("Supprimer l'utilisateur ?");
            alert.setContentText("Voulez-vous vraiment supprimer cet utilisateur ?");

            if (alert.showAndWait().get() == ButtonType.OK) {
                if (userService.deleteUserById(selectedUser.getId())) {
                    showAlert("Succès", "Utilisateur supprimé avec succès.", Alert.AlertType.INFORMATION);
                    loadUsers();
                } else {
                    showAlert("Erreur", "La suppression a échoué.", Alert.AlertType.ERROR);
                }
            }
        } else {
            showAlert("Erreur", "Veuillez sélectionner un utilisateur à supprimer.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void resetPasswordOnAction(ActionEvent actionEvent) {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert("Erreur", "Veuillez sélectionner un utilisateur pour réinitialiser son mot de passe.", Alert.AlertType.ERROR);
            return;
        }

        String tempPassword = generateTemporaryPassword(8);
        selectedUser.setPassword(tempPassword);

        if (userService.updateUser(selectedUser)) {
            showAlert("Succès", "Le mot de passe de l'utilisateur a été réinitialisé : " + tempPassword, Alert.AlertType.INFORMATION);
        } else {
            showAlert("Erreur", "Impossible de réinitialiser le mot de passe.", Alert.AlertType.ERROR);
        }
    }

    private String generateTemporaryPassword(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder password = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            password.append(characters.charAt(index));
        }
        return password.toString();
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean validateInput() {
        if (firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || usernameField.getText().isEmpty()
                || passwordField.getText().isEmpty() || roleChoiceBox.getValue() == null) {
            showAlert("Erreur", "Tous les champs doivent être remplis.", Alert.AlertType.ERROR);
            return false;
        }
        return true;
    }

    @FXML
    public void handleBackToMaintenance(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/pharmagest/maintenance.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 900, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Maintenance");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
