package com.example.pharmagest.service;

import com.example.pharmagest.model.Medicament;
import com.example.pharmagest.repository.MedicamentRepository;

import java.util.List;

public class MedicamentService {
    private final MedicamentRepository medicamentRepository = new MedicamentRepository();

    // Récupérer la liste des médicaments
    public List<Medicament> getAllMedicaments() {
        return medicamentRepository.getAllMedicaments();
    }

    // Ajouter un médicament
    public boolean addMedicament(Medicament medicament) {
        return medicamentRepository.addMedicament(medicament);
    }

    // Mettre à jour un médicament
    public boolean updateMedicament(Medicament medicament) {
        return medicamentRepository.updateMedicament(medicament);
    }

    // Supprimer un médicament par ID
    public boolean deleteMedicamentById(int id) {
        return medicamentRepository.deleteMedicamentById(id);
    }


    public void incrementerStock(int idMedicament, int i) {
    }

    public void reduireStock(int idMedicament, int i) {
    }
}
