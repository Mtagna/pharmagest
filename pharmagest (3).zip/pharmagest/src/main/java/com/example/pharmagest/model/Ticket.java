package com.example.pharmagest.model;

import java.util.List;

public class Ticket {
    private int idTicket;
    private List<Medicament> medicaments;
    private double montantTotal;
    private boolean estPaye;

    public Ticket(int idTicket, List<Medicament> medicaments) {
        this.idTicket = idTicket;
        this.medicaments = medicaments;
        this.montantTotal = calculerTotal();
        this.estPaye = false;  // Par défaut, un ticket n'est pas payé
    }

    private double calculerTotal() {
        return medicaments.stream().mapToDouble(Medicament::getPrixVente).sum();
    }

    public void setPaye(boolean paye) {
        this.estPaye = paye;
    }

    public boolean isPaye() {
        return estPaye;
    }

    public int getIdTicket() {
        return idTicket;
    }

    public double getMontantTotal() {
        return montantTotal;
    }

    public List<Medicament> getMedicaments() {
        return medicaments;
    }
}
