package com.example.pharmagest.repository;

import com.example.pharmagest.model.Medicament;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.List;

public class TicketRepository {
    private final Connection connection;

    public TicketRepository(Connection connection) {
        this.connection = connection;
    }

    public int creerVente(List<Medicament> medicaments, double montantTotal, int idVendeur, String typeVente) {
        int venteId = -1;
        String insertVenteSQL = "INSERT INTO vente (date_vente, montant_total, type_vente, idvendeur) VALUES (CURRENT_DATE, ?, ?, ?) RETURNING idvente";

        try (PreparedStatement preparedStatement = connection.prepareStatement(insertVenteSQL, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setDouble(1, montantTotal);
            preparedStatement.setString(2, typeVente);
            preparedStatement.setInt(3, idVendeur);
            preparedStatement.executeUpdate();
            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                venteId = generatedKeys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (venteId != -1) {
            String insertLigneVenteSQL = "INSERT INTO ligne_vente (idvente, idmedicament, quantite, prix_unitaire) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertLigneVenteSQL)) {
                for (Medicament medicament : medicaments) {
                    preparedStatement.setInt(1, venteId);
                    preparedStatement.setInt(2, medicament.getIdMedicament());
                    preparedStatement.setInt(3, 1); // Par défaut 1, peut être changé selon les besoins
                    preparedStatement.setDouble(4, medicament.getPrixVente());
                    preparedStatement.executeUpdate();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return venteId;
    }

    public int genererNouveauTicket(List<Medicament> medicaments) {
        return 5;
    }
}
