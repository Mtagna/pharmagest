package com.example.pharmagest.repository;

import com.example.pharmagest.model.TicketVente;
import com.example.pharmagest.database.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketVenteRepository {

    // Ajouter un nouveau ticket
    public boolean ajouterTicketVente(TicketVente ticket) {
        String sql = "INSERT INTO ticket_vente (idvente, date_ticket, statut_ticket, montant_total, idcaissier) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, ticket.getIdVente());
            pstmt.setTimestamp(2, ticket.getDateTicket());
            pstmt.setString(3, ticket.getStatutTicket());
            pstmt.setDouble(4, ticket.getMontantTotal());
            pstmt.setInt(5, ticket.getIdCaissier());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        ticket.setIdTicket(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Récupérer un ticket par ID
    public TicketVente getTicketById(int idTicket) {
        String sql = "SELECT * FROM ticket_vente WHERE idticket = ?";
        TicketVente ticket = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idTicket);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                ticket = new TicketVente(
                        rs.getInt("idticket"),
                        rs.getInt("idvente"),
                        rs.getTimestamp("date_ticket"),
                        rs.getString("statut_ticket"),
                        rs.getDouble("montant_total"),
                        rs.getInt("idcaissier")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ticket;
    }

    // Mettre à jour le statut d'un ticket (ex: payé)
    public boolean updateStatutTicket(int idTicket, String nouveauStatut) {
        String sql = "UPDATE ticket_vente SET statut_ticket = ? WHERE idticket = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nouveauStatut);
            pstmt.setInt(2, idTicket);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Liste de tous les tickets
    public List<TicketVente> getAllTickets() {
        List<TicketVente> tickets = new ArrayList<>();
        String sql = "SELECT * FROM ticket_vente";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                tickets.add(new TicketVente(
                        rs.getInt("idticket"),
                        rs.getInt("idvente"),
                        rs.getTimestamp("date_ticket"),
                        rs.getString("statut_ticket"),
                        rs.getDouble("montant_total"),
                        rs.getInt("idcaissier")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tickets;
    }
}
