package com.example.pharmagest.repository;

import com.example.pharmagest.model.Vente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.example.pharmagest.database.DatabaseConnection;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VenteRepository {

    // Ajouter une nouvelle vente
    public boolean ajouterVente(Vente vente) {
        String sql = "INSERT INTO vente (date_vente, montant_total, type_vente, idvendeur, statut_vente) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setDate(1, vente.getDateVente());
            pstmt.setDouble(2, vente.getMontantTotal());
            pstmt.setString(3, vente.getTypeVente());
            pstmt.setInt(4, vente.getIdVendeur());
            pstmt.setString(5, vente.getStatutVente());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        vente.setIdVente(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Récupérer une vente par ID
    public Vente getVenteById(int idVente) {
        String sql = "SELECT * FROM vente WHERE idvente = ?";
        Vente vente = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idVente);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                vente = new Vente(
                        rs.getInt("idvente"),
                        rs.getDate("date_vente"),
                        rs.getDouble("montant_total"),
                        rs.getString("type_vente"),
                        rs.getInt("idvendeur"),
                        rs.getString("statut_vente")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vente;
    }

    // Mettre à jour le statut d'une vente (ex: payé, finalisé)
    public boolean updateStatutVente(int idVente, String nouveauStatut) {
        String sql = "UPDATE vente SET statut_vente = ? WHERE idvente = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nouveauStatut);
            pstmt.setInt(2, idVente);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Liste de toutes les ventes
    public List<Vente> getAllVentes() {
        List<Vente> ventes = new ArrayList<>();
        String sql = "SELECT * FROM vente";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                ventes.add(new Vente(
                        rs.getInt("idvente"),
                        rs.getDate("date_vente"),
                        rs.getDouble("montant_total"),
                        rs.getString("type_vente"),
                        rs.getInt("idvendeur"),
                        rs.getString("statut_vente")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ventes;
    }

    public static void main(String[] args) {
        // Test de connexion à la base de données
        try {
            if (DatabaseConnection.getConnection() != null) {
                System.out.println("✅ Connexion réussie à PostgreSQL !");
            } else {
                System.out.println("❌ Échec de la connexion !");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        // Initialisation du repository
        VenteRepository venteRepo = new VenteRepository();

        // ====== TEST 1 : Ajouter une vente ======
        Vente nouvelleVente = new Vente(0, new Date(System.currentTimeMillis()), 50.0, "Libre", 1, "en attente");
        if (venteRepo.ajouterVente(nouvelleVente)) {
            System.out.println("✅ Vente ajoutée avec succès ! ID : " + nouvelleVente.getIdVente());
        } else {
            System.out.println("❌ Erreur lors de l'ajout de la vente !");
        }

        // ====== TEST 2 : Récupérer une vente par ID ======
        Vente venteRecuperee = venteRepo.getVenteById(nouvelleVente.getIdVente());
        if (venteRecuperee != null) {
            System.out.println("✅ Vente récupérée : " + venteRecuperee.getIdVente() + " - " + venteRecuperee.getStatutVente());
        } else {
            System.out.println("❌ Vente non trouvée !");
        }

        // ====== TEST 3 : Modifier le statut d'une vente ======
        if (venteRepo.updateStatutVente(nouvelleVente.getIdVente(), "payé")) {
            System.out.println("✅ Statut de la vente mis à jour en 'payé' !");
        } else {
            System.out.println("❌ Échec de la mise à jour du statut !");
        }

        System.out.println("✅✅✅ Tous les tests de VenteRepository sont terminés !");
    }

}
