package com.example.pharmagest.service;

import com.example.pharmagest.model.Fournisseur;
import com.example.pharmagest.repository.FournisseurRepository;

import java.util.List;

public class FournisseurService {
    private final FournisseurRepository fournisseurRepository;

    public FournisseurService() {
        this.fournisseurRepository = new FournisseurRepository();
    }

    public List<Fournisseur> getAllFournisseurs() {
        return fournisseurRepository.getAllFournisseurs();
    }

    public boolean addFournisseur(Fournisseur fournisseur) {
        return fournisseurRepository.addFournisseur(fournisseur);
    }

    public boolean updateFournisseur(Fournisseur fournisseur) {
        return fournisseurRepository.updateFournisseur(fournisseur);
    }

    public boolean deleteFournisseur(int idFournisseur) {
        return fournisseurRepository.deleteFournisseurById(idFournisseur);
    }
}
