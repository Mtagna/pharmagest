package com.example.pharmagest.repository;

import com.example.pharmagest.database.DatabaseConnection;
import com.example.pharmagest.model.User;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserRepository {

    private final DatabaseConnection databaseConnection = new DatabaseConnection();

    // Méthode pour lister tous les utilisateurs
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM public.useraccounts";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                User user = new User(
                        resultSet.getInt("iduseraccounts"),
                        resultSet.getString("firstname"),
                        resultSet.getString("lastname"),
                        resultSet.getString("username"),
                        resultSet.getString("password"),
                        resultSet.getString("role"),
                        resultSet.getTimestamp("last_login") != null
                                ? resultSet.getTimestamp("last_login").toLocalDateTime()
                                : null
                );
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }

    // Méthode pour ajouter un utilisateur
    public boolean addUser(User user) {
        String query = "INSERT INTO public.useraccounts (firstname, lastname, username, password, role, last_login) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, user.getFirstName());
            preparedStatement.setString(2, user.getLastName());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword()); // Mot de passe ajouté
            preparedStatement.setString(5, user.getRole());
            preparedStatement.setTimestamp(6, user.getLastLogin() != null ?
                    Timestamp.valueOf(user.getLastLogin()) : null);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateUser(User user) {
        String query = "UPDATE public.useraccounts " +
                "SET firstname = ?, lastname = ?, username = ?, password = ?, role = ?, last_login = ? " +
                "WHERE iduseraccounts = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Mettre à jour les colonnes
            preparedStatement.setString(1, user.getFirstName());
            preparedStatement.setString(2, user.getLastName());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword()); // Pense à hacher le mot de passe si nécessaire
            preparedStatement.setString(5, user.getRole());
            preparedStatement.setTimestamp(6, user.getLastLogin() != null ?
                    Timestamp.valueOf(user.getLastLogin()) : null);
            preparedStatement.setInt(7, user.getId()); // ID de l'utilisateur à modifier

            // Exécuter la requête
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Retourne vrai si une ligne a été modifiée

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteUserById(int id) {
        String query = "DELETE FROM public.useraccounts WHERE iduseraccounts = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Assigner l'ID dans la requête
            preparedStatement.setInt(1, id);

            // Exécuter la requête
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Retourne vrai si une ligne a été supprimée

        } catch (SQLException e) {
            e.printStackTrace(); // Affiche les erreurs SQL
            return false;
        }
    }


}
