package com.example.pharmagest.controllers;

import com.example.pharmagest.database.DatabaseConnection;
import com.example.pharmagest.util.SceneManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML
    private TextField usernameTextfield;

    @FXML
    private PasswordField passwordPasswordfield;

    @FXML
    private Label loginMessageLabel;

    @FXML
    public void loginButtonOnAction(ActionEvent actionEvent) {
        String username = usernameTextfield.getText().trim();
        String password = passwordPasswordfield.getText().trim();

        if (!username.isEmpty() && !password.isEmpty()) {
            validateLogin(username, password, actionEvent);
        } else {
            loginMessageLabel.setText("Veuillez remplir tous les champs.");
        }
    }

    private void validateLogin(String username, String password, ActionEvent actionEvent) {
        DatabaseConnection databaseConnection = new DatabaseConnection();

        String query = "SELECT COUNT(1) FROM public.useraccounts WHERE username = ? AND password = ?";

        try (Connection connection = databaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next() && resultSet.getInt(1) == 1) {
                loginMessageLabel.setText("Bienvenue dans l'application !");
                SceneManager.changeScene(actionEvent, "/com/example/pharmagest/dashboard.fxml", "Dashboard");
            } else {
                loginMessageLabel.setText("Login invalide. Veuillez réessayer.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            loginMessageLabel.setText("Erreur de connexion à la base de données.");
        }
    }
}
