package com.example.pharmagest.repository;

import com.example.pharmagest.database.DatabaseConnection;
import com.example.pharmagest.model.Fournisseur;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FournisseurRepository {

    public List<Fournisseur> getAllFournisseurs() {
        List<Fournisseur> fournisseurs = new ArrayList<>();
        String query = "SELECT * FROM public.fournisseur";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Fournisseur fournisseur = new Fournisseur(
                        resultSet.getInt("idfournisseur"),
                        resultSet.getString("nom"),
                        resultSet.getString("adresse"),
                        resultSet.getString("contact"),
                        resultSet.getString("email")
                );
                fournisseurs.add(fournisseur);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fournisseurs;
    }

    public boolean addFournisseur(Fournisseur fournisseur) {
        String query = "INSERT INTO public.fournisseur (nom, adresse, contact, email) VALUES (?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, fournisseur.getNom());
            preparedStatement.setString(2, fournisseur.getAdresse());
            preparedStatement.setString(3, fournisseur.getContact());
            preparedStatement.setString(4, fournisseur.getEmail());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    fournisseur.setIdFournisseur(generatedKeys.getInt(1)); // ✅ Récupérer l'ID généré
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateFournisseur(Fournisseur fournisseur) {
        String query = "UPDATE public.fournisseur SET nom = ?, adresse = ?, contact = ?, email = ? WHERE idfournisseur = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, fournisseur.getNom());
            preparedStatement.setString(2, fournisseur.getAdresse());
            preparedStatement.setString(3, fournisseur.getContact());
            preparedStatement.setString(4, fournisseur.getEmail());
            preparedStatement.setInt(5, fournisseur.getIdFournisseur());

            return preparedStatement.executeUpdate() > 0; // ✅ Retourne vrai si la modification a réussi

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteFournisseurById(int idFournisseur) {
        String query = "DELETE FROM public.fournisseur WHERE idfournisseur = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, idFournisseur);

            return preparedStatement.executeUpdate() > 0; // ✅ Retourne vrai si la suppression a réussi

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
