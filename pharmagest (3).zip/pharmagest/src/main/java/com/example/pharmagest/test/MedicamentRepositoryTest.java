package com.example.pharmagest.test;

import com.example.pharmagest.model.Medicament;
import com.example.pharmagest.repository.MedicamentRepository;

import java.util.List;

public class MedicamentRepositoryTest {
/*
    public static void main(String[] args) {
        MedicamentRepository medicamentRepository = new MedicamentRepository();

        // Test 1 : Ajouter un médicament
        Medicament newMedicament = new Medicament(0, "Paracetamol", "Comprimé", 2.50, 5.00, 100, 10, 200);
        boolean isAdded = medicamentRepository.addMedicament(newMedicament);
        System.out.println("Ajout réussi : " + isAdded);

        // Test 2 : Lister tous les médicaments
        List<Medicament> medicaments = medicamentRepository.getAllMedicaments();
        System.out.println("Liste des médicaments :");
        medicaments.forEach(System.out::println);

        /* Test 3 : Modifier un médicament
        if (!medicaments.isEmpty()) {
            Medicament medicamentToUpdate = medicaments.get(0);
            medicamentToUpdate.setPrixVente(6.00); // Nouveau prix de vente
            boolean isUpdated = medicamentRepository.updateMedicament(medicamentToUpdate);
            System.out.println("Modification réussie : " + isUpdated);
        }

        // Test 4 : Supprimer un médicament
        if (!medicaments.isEmpty()) {
            int idToDelete = medicaments.get(0).getId(); // ID du premier médicament
            boolean isDeleted = medicamentRepository.deleteMedicamentById(idToDelete);
            System.out.println("Suppression réussie : " + isDeleted);
        }
    }

 */
}
